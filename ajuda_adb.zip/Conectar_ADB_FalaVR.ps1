﻿# Ajuda a conectar o ADB do Quest para o FalaVR funcionar.
# Coloque este arquivo, o Conectar_ADB_FalaVR.bat e o adb.exe (com AdbWinApi.dll e AdbWinUsbApi.dll) na MESMA pasta.
$ErrorActionPreference = "Continue"
$Host.UI.RawUI.WindowTitle = "FalaVR - Conectar ADB"
$aqui = Split-Path -Parent $MyInvocation.MyCommand.Path
$adb = Join-Path $aqui "adb.exe"
$porta = 5555

function Titulo($t) { Write-Host ""; Write-Host ("=" * 62) -ForegroundColor Cyan; Write-Host "  $t" -ForegroundColor Cyan; Write-Host ("=" * 62) -ForegroundColor Cyan }
function Ok($t)   { Write-Host "  [OK]   $t" -ForegroundColor Green }
function Aviso($t){ Write-Host "  [!]    $t" -ForegroundColor Yellow }
function Erro($t) { Write-Host "  [ERRO] $t" -ForegroundColor Red }
function Info($t) { Write-Host "         $t" -ForegroundColor Gray }
function Pausa($t = "Pressione ENTER para continuar") { Read-Host $t | Out-Null }

function Adb { param([Parameter(ValueFromRemainingArguments = $true)] $args_)
    $saida = & $adb @args_ 2>&1 | ForEach-Object { "$_" }
    return ($saida -join "`n").Trim()
}

function Dispositivos {
    $txt = Adb devices
    $lista = @()
    foreach ($linha in ($txt -split "`n")) {
        if ($linha -match "^(\S+)\s+(device|unauthorized|offline|authorizing|recovery)\b") { $lista += [pscustomobject]@{ Id = $Matches[1]; Estado = $Matches[2] } }
    }
    return $lista
}

function Esperar-Dispositivo {
    # tenta algumas vezes, orientando a pessoa em cada situacao
    for ($i = 1; $i -le 6; $i++) {
        $d = Dispositivos
        $ok = $d | Where-Object { $_.Estado -eq "device" }
        if ($ok) { return $ok }
        if ($d | Where-Object { $_.Estado -eq "unauthorized" }) {
            Aviso "O Quest pediu autorização. COLOQUE O HEADSET e toque em 'Permitir' em 'Permitir depuração USB?'."
            Info "Marque 'Sempre permitir neste computador' para não perguntar de novo."
        } elseif ($d | Where-Object { $_.Estado -eq "offline" }) {
            Aviso "O Quest aparece como 'offline'. Reiniciando o ADB..."
            Adb kill-server | Out-Null; Start-Sleep 1; Adb start-server | Out-Null
        } else {
            Aviso "Nenhum Quest encontrado (tentativa $i de 6)."
            Info "Confira: cabo USB de dados (não só carga), headset LIGADO e fora do modo de espera,"
            Info "e 'Modo desenvolvedor' ativo no app Meta Horizon do celular (Dispositivos > Configurações do headset)."
        }
        Start-Sleep 4
        $null = Adb devices
    }
    return $null
}

function Ip-Do-Quest($serial) {
    $txt = Adb -s $serial shell ip -f inet addr show wlan0
    if ($txt -match "inet\s+(\d+\.\d+\.\d+\.\d+)") { return $Matches[1] }
    $txt = Adb -s $serial shell ip route
    if ($txt -match "src\s+(\d+\.\d+\.\d+\.\d+)") { return $Matches[1] }
    return $null
}

function Abrir-Desenvolvedor {
    Titulo "Abrindo as configurações de Desenvolvedor no Quest"
    Info "O headset precisa estar na sua cabeça: a tela abre dentro dele."
    $comandos = @(
        @("-a", "android.settings.APPLICATION_DEVELOPMENT_SETTINGS"),
        @("-n", 'com.android.settings/.Settings$DevelopmentSettingsDashboardActivity'),
        @("-n", "com.android.settings/.DevelopmentSettings"),
        @("-a", "android.settings.WIRELESS_SETTINGS"),
        @("-a", "android.settings.SETTINGS")
    )
    foreach ($c in $comandos) {
        $saida = Adb shell am start @c
        Info ("am start " + ($c -join " "))
        if ($saida -notmatch "Error|Exception|does not exist|not found|Permission Denial") {
            Ok "Comando aceito. Veja a tela do headset."
            return $true
        }
        Info ("   recusado: " + (($saida -split "`n")[0]))
    }
    Erro "O Quest recusou todos os atalhos. No headset: Configurações > Sistema > Desenvolvedor (ative o modo desenvolvedor pelo app Meta Horizon no celular)."
    return $false
}

function Conectar-Por-Cabo {
    Titulo "Conectando pelo cabo USB"
    Info "Reiniciando o servidor ADB..."
    Adb kill-server | Out-Null; Start-Sleep 1
    $null = Adb start-server
    $dev = Esperar-Dispositivo
    if (-not $dev) { Erro "Não consegui falar com o Quest pelo USB."; Pausa; return }
    $usb = $dev | Where-Object { $_.Id -notmatch ":" } | Select-Object -First 1
    if (-not $usb) { $usb = $dev | Select-Object -First 1 }
    Ok ("Quest encontrado: " + $usb.Id)
    $ip = Ip-Do-Quest $usb.Id
    if ($ip) { Ok "IP do Quest no Wi-Fi: $ip" } else { Aviso "Não consegui ler o IP (o Quest está no Wi-Fi?). O FalaVR ainda funciona só com o modo TCP." }

    Info "Ativando o ADB por rede (adb tcpip $porta) - é isso que o FalaVR usa..."
    $r = Adb -s $usb.Id tcpip $porta
    Info $r
    Start-Sleep 3
    if ($ip) {
        $r = Adb connect "${ip}:$porta"
        Info $r
        Start-Sleep 1
    }
    $depois = Dispositivos | Where-Object { $_.Estado -eq "device" }
    if ($depois) {
        Ok "ADB pronto. Dispositivos: $((($depois | ForEach-Object { $_.Id }) -join ', '))"
        Write-Host ""
        Write-Host "  PRONTO! Agora abra o FalaVR no Quest: o ponto deve ficar VERDE (ADB conectado)." -ForegroundColor Green
        Info "Se ainda estiver vermelho, abra o FalaVR > Configurações > ADB e toque em Conectar/Autorizar."
        Info "Depois de conectado, pode desligar o cabo. Se reiniciar o Quest, rode este arquivo de novo."
    } else {
        Erro "O ADB não ficou conectado. Veja as mensagens acima e tente a opção 5 (diagnóstico)."
    }
    Pausa
}

function Conectar-Por-Ip {
    Titulo "Conectando sem cabo (pelo IP)"
    Info "No Quest: Configurações > Sistema > Desenvolvedor > Depuração sem fio (ative)."
    Info "Ele mostra 'Endereço IP e porta' (ex.: 192.168.0.50:37123). Se pedir pareamento, escolha 'Parear com código'."
    $pareamento = Read-Host "  Precisa parear com código? (s/N)"
    if ($pareamento -match "^[sS]") {
        $alvo = Read-Host "  IP:PORTA DO PAREAMENTO (ex.: 192.168.0.50:40111)"
        $r = Adb pair $alvo
        Info $r
    }
    $alvo = Read-Host "  IP:PORTA para conectar (ex.: 192.168.0.50:37123)"
    if (-not $alvo) { return }
    Adb kill-server | Out-Null; Start-Sleep 1; $null = Adb start-server
    $r = Adb connect $alvo
    Info $r
    if ($r -match "connected") { Ok "Conectado a $alvo."; Info "Dica: depois rode a opção 1 com o cabo para ativar a porta $porta, que é a do FalaVR." }
    else { Erro "Não conectou. Confira IP/porta e se o PC e o Quest estão na MESMA rede Wi-Fi." }
    Pausa
}

function Diagnostico {
    Titulo "Diagnóstico"
    Info ("adb.exe: " + $adb)
    Info (Adb version | Select-Object -First 1)
    Write-Host ""
    Info "adb devices -l:"
    Write-Host (Adb devices -l) -ForegroundColor Gray
    $d = Dispositivos | Where-Object { $_.Estado -eq "device" } | Select-Object -First 1
    if ($d) {
        Info ("Modelo: " + (Adb -s $d.Id shell getprop ro.product.model))
        Info ("Build: " + (Adb -s $d.Id shell getprop ro.build.version.release))
        Info ("Bateria: " + ((Adb -s $d.Id shell dumpsys battery) -split "`n" | Where-Object { $_ -match "level" }))
        Info ("FalaVR instalado: " + (Adb -s $d.Id shell pm path br.com.fabyo.falavr))
        Info ("Espaço livre: " + ((Adb -s $d.Id shell df -h /sdcard) -split "`n" | Select-Object -Last 1))
    } else { Aviso "Nenhum dispositivo em estado 'device'." }
    Info "Se algo aparece como 'unauthorized', coloque o headset e permita; se 'offline', use a opção 1."
    Pausa
}

# ---------------- inicio ----------------
if (-not (Test-Path $adb)) {
    $noPath = Get-Command adb.exe -ErrorAction SilentlyContinue
    if ($noPath) { $adb = $noPath.Source } else {
        Erro "Não achei o adb.exe. Coloque o adb.exe, AdbWinApi.dll e AdbWinUsbApi.dll na mesma pasta deste arquivo."
        Pausa; exit 1
    }
}
while ($true) {
    Clear-Host
    Titulo "FalaVR - Ajuda para conectar o ADB do Quest"
    Write-Host "  1) Conectar pelo CABO USB (recomendado - faz tudo sozinho)"
    Write-Host "  2) Conectar sem cabo (pelo IP do Quest)"
    Write-Host "  3) Abrir as configurações de Desenvolvedor no Quest"
    Write-Host "  4) Reiniciar o ADB (kill-server / start-server)"
    Write-Host "  5) Diagnóstico (mostra o que o PC enxerga)"
    Write-Host "  0) Sair"
    Write-Host ""
    $op = Read-Host "  Escolha"
    switch ($op) {
        "1" { Conectar-Por-Cabo }
        "2" { Conectar-Por-Ip }
        "3" { $null = Abrir-Desenvolvedor; Pausa }
        "4" { Adb kill-server | Out-Null; Start-Sleep 1; $null = Adb start-server; Ok "ADB reiniciado."; Info (Adb devices); Pausa }
        "5" { Diagnostico }
        "0" { exit 0 }
    }
}
