@echo off
chcp 65001 >nul
title FalaVR - Conectar ADB
cd /d "%~dp0"
if not exist "%~dp0adb.exe" (
  echo.
  echo  Coloque o adb.exe ^(com AdbWinApi.dll e AdbWinUsbApi.dll^) nesta mesma pasta e abra de novo.
  echo.
  pause
  exit /b 1
)
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Conectar_ADB_FalaVR.ps1"
